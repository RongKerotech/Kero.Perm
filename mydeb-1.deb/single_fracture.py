# -*- coding: utf-8 -*-
"""
Created on Tue Nov 13 16:47:42 2018

@author: Rong
"""

import numpy as np
import my_Reactions as mR
import matplotlib.pyplot as plt
from matplotlib import ticker
import math

slopes=[5e-4,1e-3,2e-3,5e-3,1e-2,2e-2]
lengths=[1e-2,2e-2,5e-2,1e-1,2e-1,5e-1]
#lengths=np.linspace(1e-2,5e-1,50,endpoint=True)

C_upstream=1.0e-15
length=50e-2
width=1.0e-4
slope=1.e-1
viscosity=1.0e-6  #m^2 kinetic viscosity
flowrate=slope*9.81*width**2/12*width/viscosity
diffusivity=2e-9
roughness=1e-0

###for Quartz dissolution
k_kinetic=10**(-13.7)
C_eq=10**(-3.9993)

N=20
widths=np.linspace(0.5e-4,1.0e-3,N,endpoint=True)
C_downstream_Qtz=np.zeros([len(lengths),N,2])
C_downstream_Ca=np.zeros([len(lengths),N,2])
flux_Ca=np.zeros([len(lengths),N,2])
flux_Mg=np.zeros([len(lengths),N,2])
C_downstream_Mg=np.zeros([len(lengths),N,2])
Deviation_ratio_Ca=np.zeros([len(lengths),N])
Deviation_ratio_Mg=np.zeros([len(lengths),N])
flowrates=np.zeros(N)

for j in range(len(lengths)):
    length=lengths[j]
    for i in range(N):
        width=widths[i]
        flowrate=slope*9.81*width**2/12*width/viscosity
        flowrates[i]=flowrate
        '''
        C_downstream_Qtz[j][i][0]=mR.flux_zeroth_downstream_throat(C_upstream, flowrate, length, width, \
                                                   diffusivity, roughness,k_kinetic,C_eq,"mixed_transverse")/(flowrate*1e3)/C_eq
        C_downstream_Qtz[j][i][1]=mR.flux_zeroth_downstream_throat(C_upstream, flowrate, length, width, \
                                                    diffusivity, roughness,k_kinetic,C_eq,"finite_rate")/(flowrate*1e3)/C_eq
        '''
        
        
        
        R_C_relations=mR.load_R_C_relations('Rate_calcite.txt')
        flux_Ca[j][i][0]=mR.flux_RC_linInterp_downstream_throat(C_upstream, flowrate, length, width, \
                                                          diffusivity, roughness,R_C_relations,"mixed_transverse")-C_upstream*flowrate*1e3 #unit in mol/s
        flux_Ca[j][i][1]=mR.flux_RC_linInterp_downstream_throat(C_upstream, flowrate, length, width, \
                                                          diffusivity, roughness,R_C_relations,"finite_rate")-C_upstream*flowrate*1e3
    
        C_downstream_Ca[j][i][0]=flux_Ca[j][i][0]/(flowrate*1e3)
        C_downstream_Ca[j][i][1]=flux_Ca[j][i][1]/(flowrate*1e3)
        Deviation_ratio_Ca[j][i]=math.log10(flux_Ca[j][i][0]/flux_Ca[j][i][1])
        
        
        R_C_relations=mR.load_R_C_relations('Rate_magnesite.txt')
    
        flux_Mg[j][i][0]=mR.flux_RC_linInterp_downstream_throat(C_upstream, flowrate, length, width, \
                                                          diffusivity, roughness,R_C_relations,"mixed_transverse")-C_upstream*flowrate*1e3
        flux_Mg[j][i][1]=mR.flux_RC_linInterp_downstream_throat(C_upstream, flowrate, length, width, \
                                                          diffusivity, roughness,R_C_relations,"finite_rate")-C_upstream*flowrate*1e3
    
        C_downstream_Mg[j][i][0]=flux_Mg[j][i][0]/(flowrate*1e3)
        C_downstream_Mg[j][i][1]=flux_Mg[j][i][1]/(flowrate*1e3)
        Deviation_ratio_Mg[j][i]=math.log10(flux_Mg[j][i][0]/flux_Mg[j][i][1])        
        
    
#################################
#定义画图点类型
markers=["o","v","^","s","h","H","d","+","x"]
colors=['b', 'g', 'r', 'c', 'm', 'y', 'k', 'w']
"""
X,Y=np.meshgrid(widths*1000,lengths*100)
contour=plt.contourf(X,Y,Deviation_ratio_Ca,30,cmap=plt.cm.hot)
#plt.clabel(contour,fontsize=8,colors=('c'),fmt='%.2f')
plt.colorbar(contour)
plt.savefig("Ca_deviation"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf()

contour=plt.contourf(X,Y,Deviation_ratio_Mg,cmap=plt.cm.hot)
#plt.clabel(contour,fontsize=6,colors=('c'),fmt='%.2f')
plt.colorbar(contour)
plt.savefig("Mg_deviation"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf()

"""
'''
for j in range(len(lengths)):
    length=lengths[j]    
    a = plt.subplot(1,1,1)
    C1=C_downstream_Mg[j,:,1]                                       
    a1 = a.plot(widths*1000,C1*1000,colors[j]+markers[0], label = r'C$_{Conv}$'+", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    [label.set_fontname('Times New Roman') for label in labels]
    
    C1=C_downstream_Mg[j,:,0]
    a1 = a.plot(widths*1000,C1*1000,colors[j], label = r'C$_{Mix}$'", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    #a.set_ylim([0,0.25])
    
plt.xlabel("fracture width (mm)",fontname="Times New Roman")
a.set_ylabel("Outlet concentration (mM)",fontname="Times New Roman")
[label.set_fontname('Times New Roman') for label in labels]  
[label.set_fontname('Times New Roman') for label in labels]
box = a.get_position()
a.set_position([box.x0, box.y0, box.width*0.76 , box.height])
plt.legend(loc='center left', bbox_to_anchor=(0.99, 0.5))
plt.savefig("Mg_con"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf()

for j in range(len(lengths)):
    length=lengths[j]    
    a = plt.subplot(1,1,1)
    C1=flux_Mg[j,:,1]                                       
    a1 = a.plot(widths*1000,C1,colors[j]+markers[0], label = r'Q$_{Conv}$'+", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    [label.set_fontname('Times New Roman') for label in labels]
    
    C1=flux_Mg[j,:,0]
    a1 = a.plot(widths*1000,C1,colors[j], label = r'Q$_{Mix}$'", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    
formatter = ticker.ScalarFormatter(useMathText=True)
formatter.set_scientific(True) 
formatter.set_powerlimits((-1,1)) 
a.yaxis.set_major_formatter(formatter) 
plt.xlabel("fracture width (mm)",fontname="Times New Roman")
a.set_ylabel("Outlet Mg flux (Mol/s)",fontname="Times New Roman")
[label.set_fontname('Times New Roman') for label in labels]  
[label.set_fontname('Times New Roman') for label in labels]
box = a.get_position()
a.set_position([box.x0, box.y0, box.width*0.76 , box.height])
plt.legend(loc='center left', bbox_to_anchor=(0.99, 0.5))
plt.savefig("Mg_flux"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf()



for j in range(len(lengths)):
    length=lengths[j]     
    b = plt.subplot(1,1,1)
    C1=C_downstream_Ca[j,:,1]                                       
    b1 = b.plot(widths*1000,C1*1000,colors[j]+markers[0], label = r'C$_{Conv}$'+", L="+str(length)+"m")
    handles, labels = b.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = b.get_xticklabels() + b.get_yticklabels()
    [label.set_fontname('Times New Roman') for label in labels]
    
    C1=C_downstream_Ca[j,:,0]
    b1 = b.plot(widths*1000,C1*1000,colors[j], label = r'C$_{Mix}$'+", L="+str(length)+"m")
    handles, labels = b.get_legend_handles_labels()
    legend=b.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = b.get_xticklabels() + b.get_yticklabels()
    #b.set_ylim([0,0.14])    
    

plt.xlabel("fracture width (mm)",fontname="Times New Roman")
b.set_ylabel("Outlet concentration (mM)",fontname="Times New Roman")
[label.set_fontname('Times New Roman') for label in labels]    

box = b.get_position()
b.set_position([box.x0, box.y0, box.width*0.76 , box.height])
plt.legend(loc='center left', bbox_to_anchor=(0.99, 0.5))

plt.savefig("Ca_con"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf()


for j in range(len(lengths)):
    length=lengths[j]    
    a = plt.subplot(1,1,1)
    C1=flux_Ca[j,:,1]                                       
    a1 = a.plot(widths*1000,C1,colors[j]+markers[0], label = r'Q$_{Conv}$'+", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    [label.set_fontname('Times New Roman') for label in labels]
    
    C1=flux_Ca[j,:,0]
    a1 = a.plot(widths*1000,C1,colors[j], label = r'Q$_{Mix}$'", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    #a.set_ylim([0,0.25])
    

formatter = ticker.ScalarFormatter(useMathText=True)
formatter.set_scientific(True) 
formatter.set_powerlimits((-1,1)) 
a.yaxis.set_major_formatter(formatter) 
plt.xlabel("fracture width (mm)",fontname="Times New Roman")
a.set_ylabel("Outlet Ca flux (Mol/s)",fontname="Times New Roman")
[label.set_fontname('Times New Roman') for label in labels]  
[label.set_fontname('Times New Roman') for label in labels]
box = a.get_position()
a.set_position([box.x0, box.y0, box.width*0.76 , box.height])
plt.legend(loc='center left', bbox_to_anchor=(0.99, 0.5))
plt.savefig("Ca_flux"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf()    


for j in range(len(lengths)):
    length=lengths[j]    
    a = plt.subplot(1,1,1)
    C1=flux_Mg[j,:,1]/(2*length)                                       
    #a1 = a.semilogy(widths*1000,C1,colors[j]+markers[0], label = r'R$_{Conv}$'+", L="+str(length)+"m")
    a1 = a.plot(widths*1000,C1,colors[j]+markers[0], label = r'R$_{Conv}$'+", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    [label.set_fontname('Times New Roman') for label in labels]
    
    C1=flux_Mg[j,:,0]/(2*length)
    a1 = a.plot(widths*1000,C1,colors[j], label = r'R$_{Mix}$'", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    #a.set_ylim([0,0.25])
    
plt.xlabel("fracture width (mm)",fontname="Times New Roman")
a.set_ylabel("Magnesite dissolution rate (Mol/m"+r"$^2$"+"/s)",fontname="Times New Roman")
[label.set_fontname('Times New Roman') for label in labels]  
[label.set_fontname('Times New Roman') for label in labels]
box = a.get_position()
a.set_position([box.x0, box.y0, box.width*0.76 , box.height])
plt.legend(loc='center left', bbox_to_anchor=(0.99, 0.5))
plt.savefig("Magnesite dissolution rate"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf() 

for j in range(len(lengths)):
    length=lengths[j]    
    a = plt.subplot(1,1,1)
    C1=flux_Ca[j,:,1]/(2*length)                                       
    a1 = a.semilogy(widths*1000,C1,colors[j]+markers[0], label = r'R$_{Conv}$'+", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    [label.set_fontname('Times New Roman') for label in labels]
    
    C1=flux_Ca[j,:,0]/(2*length)
    a1 = a.plot(widths*1000,C1,colors[j], label = r'R$_{Mix}$'", L="+str(length)+"m")
    handles, labels = a.get_legend_handles_labels()
    legend=a.legend(handles[::-1], labels[::-1])
    plt.setp(legend.texts,fontname="Times New Roman")
    labels = a.get_xticklabels() + a.get_yticklabels()
    #a.set_ylim([0,0.25])
    
plt.xlabel("fracture width (mm)",fontname="Times New Roman")
a.set_ylabel("Calcite dissolution rate (Mol/m"+r"$^2$"+"/s)",fontname="Times New Roman")
[label.set_fontname('Times New Roman') for label in labels]  
[label.set_fontname('Times New Roman') for label in labels]
box = a.get_position()
a.set_position([box.x0, box.y0, box.width*0.76 , box.height])
plt.legend(loc='center left', bbox_to_anchor=(0.99, 0.5))
plt.savefig("Calcite dissolution rate"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf()   

'''
