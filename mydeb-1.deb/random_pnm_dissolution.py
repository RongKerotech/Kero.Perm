# -*- coding: utf-8 -*-
"""
Created on Wed Nov  7 14:39:21 2018

@author: Rong
"""
import numpy as np
import openpnm as op
import my_Reactions as mR


diffusivity_aq=2.e-9
roughness_thrt=1.0

net = op.network.Cubic(shape=[1,21,21],spacing=2.5e-2)
N_throat=len(net.Ts)
N_pore=len(net.Ps)
pore_neighbors = []
for i in range(N_pore):
    pore_neighbors.append([])
for i in range(N_throat):    
    pore_neighbors[net['throat.conns'][i][0]].append([net['throat.conns'][i][1],i])
    pore_neighbors[net['throat.conns'][i][1]].append([net['throat.conns'][i][0],i])


geom = op.geometry.StickAndBall(network=net, pores=net.Ps, throats=net.Ts)

water = op.phases.Water(network=net)
water['pore.viscosity']= np.ones(len(water['pore.viscosity']))*1e-3

phys_water = op.physics.GenericPhysics(network=net, phase=water, geometry=geom)

#############################################################################
#add something here to modify the PNM
##########################
geom['throat.diameter']=np.ones(len(geom['throat.diameter']))*1.e-3

#############################################################
##normal distribution width
sampleNo = len(geom['throat.diameter'])
mu = 6.e-4
sigma = 3.e-4
np.random.seed(0)
s = np.random.normal(mu, sigma, sampleNo )
for i in range(sampleNo):
    s[i]=max(s[i],1e-7)
geom['throat.diameter']= s

###############################################################

geom['throat.area2']=geom['throat.diameter']
geom['throat.conduit_lengths2.throat']=geom['throat.conduit_lengths.throat']\
                                    +geom['throat.conduit_lengths.pore1']\
                                    +geom['throat.conduit_lengths.pore2']
geom['throat.conduit_lengths2.pore1']=0.*geom['throat.conduit_lengths.pore1']
geom['throat.conduit_lengths2.pore2']=0.*geom['throat.conduit_lengths.pore2']
#############################################################################


model = op.models.physics.hydraulic_conductance.hagen_poiseuille


phys_water.add_model(propname='throat.hydraulic_conductance', \
                   model=model,\
                   pore_viscosity='pore.viscosity',\
                   pore_area='pore.area',\
                   throat_area='throat.area2',\
                   conduit_lengths='throat.conduit_lengths2')

phys_water['throat.hydraulic_conductance']=geom['throat.diameter']**3/12/geom['throat.conduit_lengths2.throat']/\
                                            (water['pore.viscosity'][0])



flow=op.algorithms.StokesFlow(network=net)
flow.setup(phase=water)

upstreamBC='left'
downstreamBC='right'
L=net['pore.coords'][-1][2]-net['pore.coords'][0][2]
slope=0.1
deltaP=slope*L*9.81*water['pore.density'][0]
flow.set_value_BC(pores=net.pores(upstreamBC), values=deltaP)
flow.set_value_BC(pores=net.pores(downstreamBC), values=0)

flow.run()


net['pore.pressure']=flow['pore.pressure']
net['throat.hydraulic_conductance']=phys_water['throat.hydraulic_conductance']
N_throat=len(net['throat.hydraulic_conductance'])
throat_dP=np.zeros(N_throat)
for i in range(N_throat):
    index_0=net['throat.conns'][i][0]
    index_1=net['throat.conns'][i][1]
    throat_dP[i]=net['pore.pressure'][index_0]-net['pore.pressure'][index_1]
    
flowrate=np.multiply(net['throat.hydraulic_conductance'],throat_dP)
net['throat.flowrate']=flowrate
net['throat.deltaP']=throat_dP

pressure_range=np.argsort(-net['pore.pressure'])  #按孔隙压力降序排列索引号

pore_concentration=np.zeros(N_pore)
pore_fluxin=np.zeros(N_pore)
pore_id=range(N_pore)
Cin=1e-9 # inlet concentration


R_C_relations=mR.load_R_C_relations('Rate_calcite.txt')  #load RC correlations from file
effluent_fluid_flux=0.0
effluent_solute_flux=0.0

#迎风显示求解方法
for i in range(N_pore):   
    index_i=pore_id[pressure_range[i]]
    if net['pore.'+upstreamBC][index_i]==1:
        pore_concentration[index_i]=Cin
    else:
        pore_concentration[index_i]=0.0
        pore_fluxin[index_i]=0.0
        for n_neighbors in range(len(pore_neighbors[index_i])):
            index_neighbor=pore_neighbors[index_i][n_neighbors][0]
            index_throat_neighbor=pore_neighbors[index_i][n_neighbors][1]
            if (net['pore.pressure'][index_neighbor]- net['pore.pressure'][index_i])>0.:
                pore_fluxin[index_i]+=abs(flowrate[index_throat_neighbor])   #Q in m^3/s
                ##########mass flux from upstream
                pore_concentration[index_i]+=mR.flux_RC_linInterp_downstream_throat(pore_concentration[index_neighbor],\
                                                                                  abs(flowrate[index_throat_neighbor]),\
                                                                                  geom['throat.conduit_lengths2.throat'][index_throat_neighbor],\
                                                                                  geom['throat.diameter'][index_throat_neighbor], \
                                                                                  diffusivity_aq,\
                                                                                  roughness_thrt,\
                                                                                  R_C_relations,\
                                                                                  "mixed_transverse")    #"mixed_transverse"  "finite_rate"  #mol/s
        pore_concentration[index_i]=1e-3*pore_concentration[index_i]/pore_fluxin[index_i]     #mol/L

#effluent integration
for i in range(N_pore):    
    if net['pore.'+downstreamBC][i]==1:   
        effluent_fluid_flux+= pore_fluxin[i]  #m**3/s
        effluent_solute_flux+= pore_fluxin[i]*pore_concentration[i]*1e3  #mol/s         
        
net['pore.concentration']=pore_concentration
        
print ("Qv="+ str(effluent_fluid_flux)+"m3/s")
print ("Qsolute="+str(effluent_solute_flux)+"mol/s")
print ("c_ave="+str(1e-3*effluent_solute_flux/effluent_fluid_flux))    



#Dissolution=op.algrithms.

#op.io.VTK.save(network=net)
