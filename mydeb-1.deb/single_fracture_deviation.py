# -*- coding: utf-8 -*-
"""
Created on Fri Nov 16 11:26:35 2018

@author: Rong
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Nov 13 16:47:42 2018

@author: Rong
"""

import numpy as np
import my_Reactions as mR
import matplotlib.pyplot as plt
from matplotlib import ticker
import math

slopes=[5e-4,1e-3,2e-3,5e-3,1e-2,2e-2]
lengths=[1e-2,2e-2,5e-2,1e-1,2e-1,5e-1]
lengths=np.linspace(1e-2,5e-1,50,endpoint=True)

C_upstream=1.0e-15
length=50e-2
width=1.0e-4
slope=1.e-2
viscosity=1.0e-6  #m^2 kinetic viscosity
flowrate=slope*9.81*width**2/12*width/viscosity
diffusivity=2e-9
roughness=1e2

###for Quartz dissolution
k_kinetic=10**(-13.7)
C_eq=10**(-3.9993)

N=20
widths=np.linspace(0.5e-4,1.0e-3,N,endpoint=True)
C_downstream_Qtz=np.zeros([len(lengths),N,2])
C_downstream_Ca=np.zeros([len(lengths),N,2])
flux_Ca=np.zeros([len(lengths),N,2])
flux_Mg=np.zeros([len(lengths),N,2])
C_downstream_Mg=np.zeros([len(lengths),N,2])
Deviation_ratio_Ca=np.zeros([len(lengths),N])
Deviation_ratio_Mg=np.zeros([len(lengths),N])
flowrates=np.zeros(N)

for j in range(len(lengths)):
    length=lengths[j]
    for i in range(N):
        width=widths[i]
        flowrate=slope*9.81*width**2/12*width/viscosity
        flowrates[i]=flowrate
        '''
        C_downstream_Qtz[j][i][0]=mR.flux_zeroth_downstream_throat(C_upstream, flowrate, length, width, \
                                                   diffusivity, roughness,k_kinetic,C_eq,"mixed_transverse")/(flowrate*1e3)/C_eq
        C_downstream_Qtz[j][i][1]=mR.flux_zeroth_downstream_throat(C_upstream, flowrate, length, width, \
                                                    diffusivity, roughness,k_kinetic,C_eq,"finite_rate")/(flowrate*1e3)/C_eq
        '''
        
        
        
        R_C_relations=mR.load_R_C_relations('Rate_calcite.txt')
        flux_Ca[j][i][0]=mR.flux_RC_linInterp_downstream_throat(C_upstream, flowrate, length, width, \
                                                          diffusivity, roughness,R_C_relations,"mixed_transverse")-C_upstream*flowrate*1e3 #unit in mol/s
        flux_Ca[j][i][1]=mR.flux_RC_linInterp_downstream_throat(C_upstream, flowrate, length, width, \
                                                          diffusivity, roughness,R_C_relations,"finite_rate")-C_upstream*flowrate*1e3
    
        C_downstream_Ca[j][i][0]=flux_Ca[j][i][0]/(flowrate*1e3)
        C_downstream_Ca[j][i][1]=flux_Ca[j][i][1]/(flowrate*1e3)
        Deviation_ratio_Ca[j][i]=math.log10(flux_Ca[j][i][0]/flux_Ca[j][i][1])
        
        
        R_C_relations=mR.load_R_C_relations('Rate_magnesite.txt')
    
        flux_Mg[j][i][0]=mR.flux_RC_linInterp_downstream_throat(C_upstream, flowrate, length, width, \
                                                          diffusivity, roughness,R_C_relations,"mixed_transverse")-C_upstream*flowrate*1e3
        flux_Mg[j][i][1]=mR.flux_RC_linInterp_downstream_throat(C_upstream, flowrate, length, width, \
                                                          diffusivity, roughness,R_C_relations,"finite_rate")-C_upstream*flowrate*1e3
    
        C_downstream_Mg[j][i][0]=flux_Mg[j][i][0]/(flowrate*1e3)
        C_downstream_Mg[j][i][1]=flux_Mg[j][i][1]/(flowrate*1e3)
        Deviation_ratio_Mg[j][i]=math.log10(flux_Mg[j][i][0]/flux_Mg[j][i][1])        
        
    
#################################
#定义画图点类型
markers=["o","v","^","s","h","H","d","+","x"]
colors=['b', 'g', 'r', 'c', 'm', 'y', 'k', 'w']

X,Y=np.meshgrid(widths*1000,lengths*100)
contour=plt.contourf(X,Y,Deviation_ratio_Ca,30,cmap=plt.cm.hot)
#plt.clabel(contour,fontsize=8,colors=('c'),fmt='%.2f')
plt.colorbar(contour)
plt.savefig("Ca_deviation"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf()

contour=plt.contourf(X,Y,Deviation_ratio_Mg,cmap=plt.cm.hot)
#plt.clabel(contour,fontsize=6,colors=('c'),fmt='%.2f')
plt.colorbar(contour)
plt.savefig("Mg_deviation"+"_Slope_"+str(slope)+"_Roughness_"+str(roughness)+".jpg",dpi=200)
plt.clf()

