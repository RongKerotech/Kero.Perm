# -*- coding: utf-8 -*-
"""
Created on Fri Mar  1 08:09:32 2019

@author: Rong
"""
import numpy as np
import my_Reactions as mR
import matplotlib.pyplot as plt
from matplotlib import ticker
from matplotlib import mlab
from matplotlib import rcParams

#################################
#定义画图点类型
markers=["o","v","^","s","h","H","d","+","x"]
colors=['b', 'g', 'r', 'c', 'm', 'y', 'k', 'w']


#T_total=1000  #year
#N_dT=500
#dT=T_total*365*3600*24/N_dT   #s
#Qv=np.zeros(N_dT)
#Qsolute=np.zeros(N_dT)
#Cout=np.zeros(N_dT)
Times=np.arange(0,T_total,dT)

  

a = plt.subplot(1,1,1)
a1 = a.plot(Times[i][j],Qsolute[i][j],colors[i]+markers[j], label =r'w$_{ave}$='+str(mus[i]*1e3))
handles, labels = a.get_legend_handles_labels()
legend=a.legend(handles[::-1], labels[::-1])
plt.setp(legend.texts,fontname="Times New Roman")
labels = a.get_xticklabels() + a.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]
        
plt.xlabel("time (y)",fontname="Times New Roman")
a.set_ylabel("Qsolute (mol/s)",fontname="Times New Roman")
#a.set_ylabel("Cout (mol/L)",fontname="Times New Roman")
[label.set_fontname('Times New Roman') for label in labels]  
[label.set_fontname('Times New Roman') for label in labels]
box = a.get_position()
#a.set_position([box.x0, box.y0, box.width*0.74 , box.height])
#plt.legend(loc='center left', bbox_to_anchor=(0.99, 0.5))
plt.savefig("Mgn"+"_T-Qsolute_"+"exponential"+".jpg",dpi=200)
plt.clf()
   
